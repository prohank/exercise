package com.example.poc.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class FileUtils {

	public Trie getWordTrieFromFile(String fileName) {

		Trie trie = new Trie();
		File file = new File(fileName);
		try {
			BufferedReader br = new BufferedReader(
					new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8));

			String line;
			while ((line = br.readLine()) != null) {
				trie.insert(line.toLowerCase().replaceAll("\'", ""));
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return trie;
	}

	public List<String> getWordListFromFile(String file) {

		List<String> lines = Collections.emptyList();
		try {
			lines = Files.readAllLines(Paths.get(file), StandardCharsets.UTF_8);
		}

		catch (IOException e) {

			e.printStackTrace();
		}
		return lines;
	}
}
