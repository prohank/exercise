package com.example.poc.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.example.poc.utils.Trie;
import com.example.poc.utils.TrieNode;

@Service
public class PocServiceImpl implements PocService {

	@Autowired
	@Qualifier("wordTrie")
	private Trie wordTrie;

	@Autowired
	@Qualifier("wordList")
	private List<String> wordList;

	@Override
	public List<String> getAllMatchingWords(String startingWith) {
		if (Objects.isNull(wordTrie))
			return Collections.emptyList();
		startingWith = startingWith.toLowerCase();
		List<String> resultList = new ArrayList<>();
		TrieNode node = wordTrie.searchPrefix(startingWith);
		if (Objects.nonNull(node)) {
			resultList = wordTrie.getTrieFrom(node, startingWith);
		}

		return resultList;
	}

	@Override
	public List<String> getMatchingWordsFromList(String startingWith) {
		if (wordList.isEmpty())
			return Collections.emptyList();
		List<String> resultList = new ArrayList<String>();
		String word;
		for (int i = 0; i < wordList.size(); i++) {
			word = wordList.get(i).toLowerCase();
			if (word.startsWith(startingWith.toLowerCase())) {
				resultList.add(wordList.get(i));
			}
		}
		return resultList;
	}

}
