import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';

@Injectable({
	providedIn: 'root'
})
export class AppService {

	private wordsUrl: string;
	public isLoading = new BehaviorSubject<boolean>(false);

	constructor(private http: HttpClient) {
		this.wordsUrl = 'http://localhost:8080/api/words';
	}

	public findAll(chars: String): Observable<String[]> {
		let findSuggestionsUrl = this.wordsUrl + "/" + chars;
		return this.http.get<String[]>(findSuggestionsUrl);
	}
}
