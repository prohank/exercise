package com.example.poc.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.example.poc.utils.FileUtils;

@Configuration
public class PocConfig implements WebMvcConfigurer{

	private static final String fileName = "dictionary.txt";

	@Autowired
	private FileUtils fileUtils;
	
	@Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/**").allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS");
    }

	@Bean("words")
	public List<String> getWordsFromFile() {
		// Populating words list by reading from file at application startup
		List<String> words = fileUtils.getWordsFromFile(fileName);

		// Testing
//		Trie wordTrie = new Trie();
//		List<String> resultList = new ArrayList<>();
//		if (Objects.isNull(words))
//			return Collections.emptyList();
//		words.forEach(word -> wordTrie.insert(word.toLowerCase().replaceAll("\'", "")));
//		TrieNode node = wordTrie.searchPrefix("zw");
//		if (Objects.nonNull(node)) {
//			resultList = wordTrie.getTrieFrom(node, "zw");
//		}
//		resultList.forEach(System.out::println);
//
//		return resultList;

		return words;
	}

}
