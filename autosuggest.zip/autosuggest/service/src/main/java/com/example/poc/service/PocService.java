package com.example.poc.service;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface PocService {

	List<String> getAllMatchingWords(String startingWith);
}
