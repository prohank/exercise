package com.example.poc.utils;

import java.util.ArrayList;
import java.util.List;

public class Trie {

	private final int ALPHA_SIZE = 26;

	TrieNode root;

	public Trie() {
		root = new TrieNode();
	}

	public void insert(String word) {
		TrieNode node = root;
		for (int i = 0; i < word.length(); i++) {
			char currentChar = word.charAt(i);
			if (!node.containsChar(currentChar)) {
				node.put(currentChar, new TrieNode());
			}
			node = node.get(currentChar);
		}
		node.setEnd();
	}

	public boolean search(String word) {
		TrieNode node = searchPrefix(word);
		return node != null;
	}

	public TrieNode searchPrefix(String word) {
		TrieNode node = root;
		for (int i = 0; i < word.length(); i++) {
			char currentChar = word.charAt(i);
			if (node.containsChar(currentChar))
				node = node.get(currentChar);
			else
				return null;

		}
		return node;
	}

	public List<String> getTrieFrom(TrieNode node, String startingWith) {
		String s = startingWith;
		List<String> foundWords = new ArrayList<>();
		getTrieNodesRecursive(node, s, foundWords);
		return foundWords;
	}

	private void getTrieNodesRecursive(TrieNode node, String s, List<String> foundWords) {
		if (node != null) {
			if (node.isEnd()) {
				foundWords.add(s);
			}
			for (int k = 0; k < ALPHA_SIZE; k++)
				if (null != node.getChild(k)) {
					getTrieNodesRecursive(node.getChild(k), s + (char) (k + 'a'), foundWords);
				}
		}
	}

}
