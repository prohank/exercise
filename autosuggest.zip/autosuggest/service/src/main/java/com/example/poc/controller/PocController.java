package com.example.poc.controller;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.poc.service.PocService;

@RestController
@RequestMapping("/api")
public class PocController {

	@Autowired
	PocService service;

	@GetMapping("/words/{chars}")
	public List<String> getWords(@PathVariable(value = "chars") String prefix) {
		if (!StringUtils.isEmpty(prefix))
			return service.getAllMatchingWords(prefix);
		else
			return Collections.emptyList();
	}

}
