package com.example.poc.utils;

public class TrieNode {
	private final TrieNode[] links;
	private final int ALPHA_SIZE = 26;
	private boolean isEnd;

	TrieNode() {
		links = new TrieNode[ALPHA_SIZE];
	}

	public boolean containsChar(int ch) {
		return links[ch - 'a'] != null;
	}

	public TrieNode get(int ch) {
		return links[ch - 'a'];
	}

	public void put(int ch, TrieNode node) {
		this.links[ch - 'a'] = node;
	}

	public boolean isEnd() {
		return isEnd;
	}

	public void setEnd() {
		isEnd = Boolean.TRUE;
	}

	public TrieNode getChild(int i) {
		return links[i];
	}
}
