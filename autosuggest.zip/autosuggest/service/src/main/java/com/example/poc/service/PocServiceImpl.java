package com.example.poc.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.example.poc.utils.Trie;
import com.example.poc.utils.TrieNode;

@Service
public class PocServiceImpl implements PocService {

	@Autowired
	@Qualifier("words")
	private List<String> words;

	private Trie wordTrie;

	@Override
	public List<String> getAllMatchingWords(String startingWith) {
		List<String> resultList = new ArrayList<>();
		if (Objects.isNull(words))
			return Collections.emptyList();
		if (Objects.isNull(wordTrie)) {
			wordTrie = new Trie();
			// Converting all words to lower case and ignoring Apostrophe(') for now
			words.forEach(word -> wordTrie.insert(word.toLowerCase().replaceAll("\'", "")));
		}
		TrieNode node = wordTrie.searchPrefix(startingWith);
		if (Objects.nonNull(node)) {
			resultList = wordTrie.getTrieFrom(node, startingWith);
		}

		return resultList;
	}

}
